#imports necessários
from django.apps import AppConfig

#configuração da app_cad_atividades
class AppCadAtividadesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
 #indica o nome da app
    name = 'app_cad_atividades'
